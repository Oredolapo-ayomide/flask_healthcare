import csv
from pymongo import MongoClient

# Connect to Mongo
client = MongoClient(
    "mongodb+srv://ogunsijiayomide02:test12@ayomide.tkbmxfa.mongodb.net/FLASK?retryWrites=true&w=majority&appName=ayomide")
db = client["FLASK"]
collection = db["HEALTHCARE_INFO"]


class User:
    def __init__(self, name, age, gender, income, expenses):
        self.name = name
        self.age = age
        self.gender = gender
        self.income = income
        self.expenses = expenses

    def to_dict(self):
        return {
            "Name": self.name,
            "Age": self.age,
            "Gender": self.gender,
            "Income": self.income,
            "Utilities": self.expenses.get("utilities", 0),
            "Entertainment": self.expenses.get("entertainment", 0),
            "School_Fees": self.expenses.get("school_fees", 0),
            "Shopping": self.expenses.get("shopping", 0),
            "Healthcare": self.expenses.get("healthcare", 0),
        }


def export_users_to_csv():
    users = []

    # Fetch data from Mongo
    for record in collection.find():
        user = User(
            record.get("name"),
            record.get("age"),
            record.get("gender"),
            record.get("income"),
            record.get("expenses", {})
        )
        users.append(user.to_dict())

    if not users:
        print("No data found in database!")
        return

    # Export to CSV
    filename = "survey_data.csv"
    with open(filename, mode="w", newline="", encoding="utf-8") as file:
        writer = csv.DictWriter(file, fieldnames=users[0].keys())
        writer.writeheader()
        writer.writerows(users)

    print(f"✅ Data exported successfully to {filename}")


if __name__ == "__main__":
    export_users_to_csv()
