from flask import Flask
from .database import mongo_db


def create_app():
    app = Flask(__name__)

    app.config["MONGO_URI"] = "mongodb+srv://ogunsijiayomide02:test12@ayomide.tkbmxfa.mongodb.net/FLASK?retryWrites=true&w=majority&appName=ayomide"

    with app.app_context():
        try:
            mongo_db.command("ping")
            print("✅ MongoDB connection successful")
        except Exception as e:
            print("❌ MongoDB connection failed:", e)

    from .routes import main
    app.register_blueprint(main)

    return app
