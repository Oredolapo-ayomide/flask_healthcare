from pymongo import MongoClient

client = MongoClient(
    "mongodb+srv://ogunsijiayomide02:test12@ayomide.tkbmxfa.mongodb.net/FLASK?retryWrites=true&w=majority&appName=ayomide"
)

mongo_db = client["FLASK"]
