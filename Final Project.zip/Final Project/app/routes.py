from flask import Blueprint, render_template, request
from .database import mongo_db   # import mongo from database.py

main = Blueprint("main", __name__)


@main.route("/")
def home():
    return render_template("index.html")


@main.route("/submit", methods=["POST"])
def submit():
    name = request.form.get("name")
    age = request.form.get("age")
    gender = request.form.get("gender")
    income = request.form.get("income")

    expenses_selected = request.form.getlist("expenses")
    expenses = {}
    for expense in expenses_selected:
        amount = request.form.get(f"{expense}_amount")
        if amount:  # only store if user entered an amount
            expenses[expense] = float(amount)

    # save to MongoDB
    mongo_db["HEALTHCARE_INFO"].insert_one({
        "name": name,
        "age": age,
        "gender": gender,
        "income": income,
        "expenses": expenses
    })

    return f"✅ Thank you! Data saved for {name}."
