from pptx import Presentation
from pptx.util import Inches, Pt

# Create a new presentation
prs = Presentation()

# Slide 1: Title
slide_title = prs.slides.add_slide(prs.slide_layouts[0])
slide_title.shapes.title.text = "Healthcare Survey Analysis"
slide_title.placeholders[1].text = "Generated charts from survey data"

# Slide 2: Average Income by Age
slide_income = prs.slides.add_slide(prs.slide_layouts[5])
slide_income.shapes.title.text = "Average Income by Age"
slide_income.shapes.add_picture(
    "income_by_age.png", Inches(1), Inches(1.5), width=Inches(8))

# Slide 3: Average Income by Name
slide_income = prs.slides.add_slide(prs.slide_layouts[5])
slide_income.shapes.title.text = "Average Income by Name"
slide_income.shapes.add_picture(
    "income_by_Name.png", Inches(1), Inches(1.5), width=Inches(8))

# Slide 4: Gender Distribution Across Spending Categories
slide_spending = prs.slides.add_slide(prs.slide_layouts[5])
slide_spending.shapes.title.text = "Gender Distribution Across Spending Categories"
slide_spending.shapes.add_picture(
    "spending_by_gender.png", Inches(1), Inches(1.5), width=Inches(8))

# Slide 5: Conclusion & Recommendations
slide_conclusion = prs.slides.add_slide(prs.slide_layouts[5])
slide_conclusion.shapes.title.text = "Conclusion & Recommendations"

content = (
    "- Income drives spending more than gender.\n"
    "- School fees, healthcare, and utilities dominate expenses.\n"
    "- Focus on income-based segmentation.\n"
    "- Develop targeted savings/investment products.\n"
    "- Collect more data for deeper insights."
)

txBox = slide_conclusion.shapes.add_textbox(
    Inches(1), Inches(1.5), Inches(8), Inches(4))
tf = txBox.text_frame
p = tf.add_paragraph()
p.text = content
p.font.size = Pt(18)

# Save the presentation
prs.save("Healthcare_Survey_Analysis.pptx")
print("✅ PowerPoint presentation created successfully!")
